var app = angular.module('app', []);

app.controller('MainCtrl', function($scope) {
  $scope.name = 'World';
});

app.controller('Page2Ctrl', function($scope) {
  $scope.name = 'Page 2';
});

app.controller('Page3Ctrl', function($scope) {
  $scope.name = 'Page 3';
});

app.controller('Page4Ctrl', function($scope) {
  $scope.name = 'Page 4';
});

app
  .config(["$routeProvider", "$httpProvider",
    function($routeProvider, $httpProvider) {
      // content headers
      $httpProvider.defaults.headers.post = $httpProvider.defaults.headers.post || {};
      $httpProvider.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded;charset=utf-8";

      $httpProvider.defaults.headers.get = $httpProvider.defaults.headers.get || {};
      $httpProvider.defaults.headers.get.Accept = "application/x-javascript, text/plain, */*";

      var options = {transition: "slide", speed: "fast"};
      $routeProvider
        .when("/",       {jqmOptions: options, redirectTo: "/page1/"})
        .when("/page1/", {jqmOptions: options, templateUrl: "#main"})
        .when("/page2/", {jqmOptions: options, templateUrl: "/page2.html"})
        .when("/page3/", {jqmOptions: options, templateUrl: "/page3.html"});
    }])
   .run(["$rootScope", "$location",
    function($rootScope, $location) {
      // watch location changes for 404s
      $rootScope.$watch(function() {
        return $location.path();
      },
      function(to_path, from_path) {
        console.log("to_path", to_path, "from_path", from_path);
      });
    }]);